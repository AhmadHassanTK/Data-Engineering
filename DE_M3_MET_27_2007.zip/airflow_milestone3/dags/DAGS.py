from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator


from UK_Accidents_2007 import extract_clean
from UK_Accidents_2007 import load_to_postgres
from UK_Accidents_2007 import extract_additional_resources
from UK_Accidents_2007 import DashBoard



default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    'start_date': days_ago(2),
    "retries": 1,
}

dag = DAG(
    'UK_Accidents_2007_etl_pipeline',
    default_args=default_args,
    description='UK_Accidents_2007 etl pipeline',
)
with DAG(
    dag_id = 'UK_Accidents_2007_etl_pipeline',
    schedule_interval = '@once',
    default_args = default_args,
    tags = ['UK_Accidents_2007-pipeline'],
)as dag:
    
 
    load_to_postgres_task=PythonOperator(
        task_id = 'load_to_postgres',
        python_callable = load_to_postgres,
        op_kwargs={
            "filename": "/opt/airflow/data/2007_Accidents_UK_cleanedANDtransformed.csv",
            "filename2": "/opt/airflow/data/lookup_table.csv"

        },
    )
    extract_clean_task= PythonOperator(
        task_id = 'Cleaned_And_Transfromed_Dataset',
        python_callable = extract_clean,
        op_kwargs={
            "filename": '/opt/airflow/data/2007_Accidents_UK.csv'
        },
    )
    

    extract_additionalResources_task=PythonOperator(
        task_id = 'Dataset_with_additional_resources',
        python_callable = extract_additional_resources,
        op_kwargs={
            "filename": "/opt/airflow/data/2007_Accidents_UK_cleanedANDtransformed.csv"
        },
    )
    create_dashboard_task= PythonOperator(
        task_id = 'create_dashboard_task',
        python_callable = DashBoard,
        op_kwargs={
            "filename": "/opt/airflow/data/2007_Accidents_UK.csv"
        },
    )

   

    extract_clean_task >> extract_additionalResources_task >>load_to_postgres_task >>create_dashboard_task