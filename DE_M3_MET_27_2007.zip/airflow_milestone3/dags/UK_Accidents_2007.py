import pandas as pd
import numpy as np
from sklearn import preprocessing
import datetime
import math
import dash
import dash_core_components as dcc
import dash_html_components as html
from sqlalchemy import create_engine
from geopy.geocoders import Nominatim
import plotly.express as px 
from dash import Dash, dcc, html, Input, Output
import dash_core_components as dcc
import dash_html_components as html
import matplotlib.pyplot as plt
import seaborn as sns


dataset = '2007_Accidents_UK.csv'

lookupDF = pd.DataFrame(columns=['feature','value before','value after'])


def extract_clean(filename):
    df = pd.read_csv(filename)
    df = clean_missing(df)
    df = remove_outliers(df)
    df = discretization(df)
    df = ADDCOLUMN(df)
    df = normalization(df)
    df = encoding(df)


    try:    
        df.to_csv('/opt/airflow/data/2007_Accidents_UK_cleanedANDtransformed.csv',index=False,mode='x')
        lookupDF.to_csv('/opt/airflow/data/lookup_table.csv',index=False,mode='x')
        print('loaded after cleaning succesfully')
    except FileExistsError:
        print('file already exists')

def extract_additional_resources(filename):
    df = pd.read_csv(filename)
    df = API(df)
    try:    
        df.to_csv('/opt/airflow/data/2007_Accidents_UK_With_Extracted_data.csv',index=False,mode='x')
        print('loaded after API succesfully')
    except FileExistsError:
        print('file already exists')

def PartOfTheDay(dateTime):
    result =''
    if ((dateTime.time()>=datetime.time(5, 0))&(dateTime.time()<=datetime.time(12, 0))) :
        result='Morning'
    elif ((dateTime.time()>datetime.time(12, 0))&(dateTime.time()<=datetime.time(17, 0))) :
        result='Afternoon' 
    elif((dateTime.time()>datetime.time(17, 0))&(dateTime.time()<=datetime.time(21, 0))) :
        result='Evening' 
    else :
        result='Night'
    return result

def ADDCOLUMN(df):
    time= pd.to_datetime(df['time'])
    df['Part Of The Day']=[PartOfTheDay(x) for x in time]
    df[['Part Of The Day','time']]
    return df

def API(df):
    geolocator = Nominatim(user_agent="http")
    cities  = df['local_authority_district'].unique().tolist()
    df['Country'] = df['local_authority_district']
    for i in range(0,len(cities)):
            if('and' in cities[i]):
                print(i)
                z = cities[i].split(' ')
                location = geolocator.geocode(z[0].strip(),timeout=None)
                if('대한민국' in location.raw['display_name'] or 'नेपाल' in location.raw['display_name']):
                    location = geolocator.geocode(z[0].strip()+' District',timeout=None)
                    x = location.raw['display_name'].split(',')
                    y = x[len(x)-1].strip()
                    print(y)
                    df['Country'] = df['Country'].replace(cities[i],y)
                else:
                    x = location.raw['display_name'].split(',')
                    y = x[len(x)-1].strip()
                    print(y)
                    df['Country'] = df['Country'].replace(cities[i],y)
                
            else:
                location = geolocator.geocode(z[0].strip(),timeout=None)
                if('대한민국' in location.raw['display_name']):
                    print(i)
                    location = geolocator.geocode(z[0].strip()+' District',timeout=None)
                    x = location.raw['display_name'].split(',')
                    y = x[len(x)-1].strip()
                    print(y)
                    df['Country'] = df['Country'].replace(cities[i],y)
                elif(cities[i] == 'Arun'):
                    print(i)
                    location = geolocator.geocode(z[0].strip()+' District',timeout=None)
                    x = location.raw['display_name'].split(',')
                    y = x[len(x)-1].strip()
                    print(y)
                    df['Country'] = df['Country'].replace(cities[i],y)    
                else:  
                    print(i)
              #  location = geolocator.geocode(cities[i],timeout=None)
                    x = location.raw['display_name'].split(',')
                    y = x[len(x)-1].strip()
                    print(y)
                    df['Country'] = df['Country'].replace(cities[i],y)
         
    return df


def listToString(s):
    str1 = ""
    for ele in s:
        str1 += ele
    return str1


def clean_missing(df):

  AllColumns = df.columns.values.tolist()
  x = "first_road_class is C or Unclassified. These roads do not have official numbers so recorded as zero "
  y = "Data missing or out of range"
  z = "-1"
  w =-1
  for i in range(len(AllColumns)):
    colToStr= df[AllColumns[i]].astype(str)
    if (x in df[AllColumns[i]].values):
           df[AllColumns[i]] = df[AllColumns[i]].replace(x,0)
           df[AllColumns[i]] = pd.to_numeric( df[AllColumns[i]], errors='coerce')
           df[AllColumns[i]] = df[AllColumns[i]].astype(float)
           lookupDF.loc[len(lookupDF)]= [AllColumns[i],x,0]

    if(y in df[AllColumns[i]].values):
           if(df[AllColumns[i]].mode()[0] == y):
                  df[AllColumns[i]] = df[AllColumns[i]].replace(y,method="pad")
                  df[AllColumns[i]] = df[AllColumns[i]].replace(y,df[AllColumns[i]].mode()[0])
           else:
                df[AllColumns[i]] = df[AllColumns[i]].replace(y,df[AllColumns[i]].mode()[0])
           lookupDF.loc[len(lookupDF)]= [AllColumns[i],y,df[AllColumns[i]].mode()[0]]
    if(z in df[AllColumns[i]].values) :
          if(df[AllColumns[i]].mode()[0] == z):
                  df[AllColumns[i]] = df[AllColumns[i]].replace(z,method="pad")
                  df[AllColumns[i]] = df[AllColumns[i]].replace(z,df[AllColumns[i]].mode()[0])
          else:
                df[AllColumns[i]] = df[AllColumns[i]].replace(z,df[AllColumns[i]].mode()[0])
          lookupDF.loc[len(lookupDF)]= [AllColumns[i],z,df[AllColumns[i]].mode()[0]]  
    if(w in df[AllColumns[i]].values) :
          if(df[AllColumns[i]].mode()[0] == w):
                  df[AllColumns[i]] = df[AllColumns[i]].replace(w,method="pad")
                  df[AllColumns[i]] = df[AllColumns[i]].replace(w,df[AllColumns[i]].mode()[0])
          else:
                df[AllColumns[i]] = df[AllColumns[i]].replace(w,df[AllColumns[i]].mode()[0])
          lookupDF.loc[len(lookupDF)]= [AllColumns[i],w,df[AllColumns[i]].mode()[0]]
       
 
    NumericalColumns = df._get_numeric_data().columns.values.tolist()
                      
    for i in range(len(NumericalColumns)):
         if(df[NumericalColumns[i]].isnull().sum() > 0):
                df[NumericalColumns[i]]=df[NumericalColumns[i]].fillna(value = df[NumericalColumns[i]].mean())
                lookupDF.loc[len(lookupDF)]= [AllColumns[i],'NaN',df[NumericalColumns[i]].mean()]
                
    for i in range(len(AllColumns)):
         if(df[AllColumns[i]].isnull().sum() > 0):
               df[AllColumns[i]]=df[AllColumns[i]].fillna(value = df[AllColumns[i]].mode()[0])
               lookupDF.loc[len(lookupDF)]= [AllColumns[i],'NaN',df[AllColumns[i]].mode()[0]]
  
    return df


def removal(x,min,max):
    if(x>max):
        x=max
    elif(x<min):
        x=min
    return x  


def remove_outliers(df):
   NumericalColumns = df._get_numeric_data().columns.values.tolist()
   for i in range(len(NumericalColumns)):
    a = df[NumericalColumns[i]].quantile(0.25)
    b = df[NumericalColumns[i]].quantile(0.75)
    IQR = b-a
    min = a - (1.5*IQR)
    max = b + (1.5*IQR)
    df[NumericalColumns[i]] = df[NumericalColumns[i]].apply(removal,args=(min,max)) 


    return df



def discretization(df):
    df['date']=pd.to_datetime(df['date'])
    df['date']
    pd.to_datetime(df['date'] , format='%d/%m/%Y')
    x=pd.to_datetime(df['date'] , format='%d/%m/%Y')
    df['Week Number']=[z.weekofyear for z in x ]

    return df



def normalization(df):
    NumericalColumns = df._get_numeric_data().columns.values.tolist()
    NumericalColumns.remove('accident_year') #drop accident year because we we wont use it in calculations because its the year number
    NumericalColumns.remove('longitude')
    NumericalColumns.remove('latitude')
    NumericalColumns.remove('number_of_casualties')
    #min-max normalization for selected features range from 0-1
    for column in NumericalColumns:
       df[column]=(df[column]-df[column].min())/(df[column].max()-df[column].min())

    return df


def encoding(df):
    beEncoded = df.select_dtypes(include=['object']).copy()
    beEncoded=beEncoded.drop(['accident_reference','lsoa_of_accident_location','accident_index','local_authority_district'],axis=1)
    for column in beEncoded:
       print(column)
       if(len(df[column].value_counts())>5): #we do lable encoding for features with more than 5 unique values. the rest we one hot encode them
        df = labelEncode(df,column)
    else:
        df = oneHot(df,column)

    return df


def labelEncode(df,feature): #lable encoding +inserting the encoded data in a csv file
    dftemp = df.copy()
    label_encoder = preprocessing.LabelEncoder()
    df[feature]= label_encoder.fit_transform(df[feature])
    for i in range(0,(len(df[feature].value_counts().keys().tolist()))):
        lookupDF.loc[len(lookupDF)]= [feature,dftemp[feature].value_counts().keys().tolist()[i],df[feature].value_counts().keys().tolist()[i]]
    
    return df


def oneHot(df, feature): #one hot encoding
    dummies = pd.get_dummies(df[feature],prefix =feature)
    df=df.drop(feature,axis=1)
    result = pd.concat([df, dummies], axis=1)
    return result



def load_to_csv(df,filename):
    df.to_csv(filename,index=False)


def load_to_postgres(filename,filename2): 
    df = pd.read_csv(filename)
    df2 = pd.read_csv(filename2)
    engine = create_engine('postgresql://root:root@pgdatabase:5432/UK_Accidents_2007_etl')
    if(engine.connect()):
        print('connected succesfully')
    else:
        print('failed to connect')
    df.to_sql(name = 'UK_Accidents_2007',con = engine,if_exists='replace')
    df2.to_sql(name = 'lookup_table',con = engine,if_exists='replace')

    
    



def scatter(df):
    age_counts = df.groupby(['number_of_casualties'])['number_of_vehicles'].sum() 
    fig_title="Relationship between number of casualties and number of vehicles"
    fig = px.scatter(x=age_counts.index, y=age_counts)
    fig.update_layout(
    title=fig_title,
    xaxis_title="number of casualties",
    yaxis_title="number of vehicles")
    return fig



def DashBoard(filename):
    df = pd.read_csv(filename)
    app = Dash()
    app.layout = html.Div([
    html.H1("Web Application Dashboards with Dash", style={'text-align': 'center'}),
    html.Br(),
    html.H1("UK Accidents 2007 dataset", style={'text-align': 'center'}),
    html.Br(),
    html.Div(),
    html.H1("Relationship between number of casualties and number of survivors", style={'text-align': 'center'}),
    dcc.Graph(figure=scatter(df)),
    html.Br(),
    html.Div(),
    html.H1("Police force Histogram", style={'text-align': 'center'}),
    dcc.Graph(figure= px.histogram(df,x="police_force")),
    html.H1("Urban or rural area Histogram", style={'text-align': 'center'}),
    dcc.Graph(figure= px.histogram(df,x="urban_or_rural_area")),
    html.H1("Accident severity Histogram", style={'text-align': 'center'}),
    dcc.Graph(figure= px.histogram(df,x='accident_severity')),
    html.Br(),
    html.H1("Speed limit Histogram", style={'text-align': 'center'}),
    dcc.Graph(figure= px.histogram(df,x='speed_limit')),
    
    ])
    app.run_server(host='0.0.0.0')    
 